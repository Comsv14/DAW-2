function Ejercicio1() {
    /*Hacer un programa que contenga una función llamada vernumeros() que permita visualizar los 10 primeros números tantas veces como queramos*/
    for (let i = 0; i < 11; i++) {
        document.write(i);
    }

    }